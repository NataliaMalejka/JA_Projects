#pragma once

void __fastcall Asm_medianFilter(int w, int h, unsigned char* from, unsigned char* to, int nBlocks);